// Конфигурация прокси для обхода блокировок Telegram API
// Раскомментируйте и настройте при необходимости

module.exports = {
  // Типы прокси: 'http', 'socks5', 'https'
  // Примеры настройки:
  
  // 1. HTTP прокси
  // proxy: {
  //   host: 'proxy.example.com',
  //   port: 8080,
  //   username: 'user',
  //   password: 'pass'
  // },
  // type: 'http'
  
  // 2. SOCKS5 прокси
  // proxy: {
  //   host: 'socks.example.com',
  //   port: 1080,
  //   username: 'user',
  //   password: 'pass'
  // },
  // type: 'socks5'
  
  // 3. Без прокси (по умолчанию)
  proxy: null,
  type: null,
  
  // Дополнительные настройки
  requestOptions: {
    timeout: 30000,  // 30 секунд таймаута
    agentOptions: {
      keepAlive: true,
      maxSockets: 10
    }
  }
};