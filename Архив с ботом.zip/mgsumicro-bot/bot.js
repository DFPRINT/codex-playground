const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs-extra');
const path = require('path');
const moment = require('moment');
const cron = require('node-cron');
const winston = require('winston');

// Загрузка конфигурации
const config = require('./config.json');

// Настройка логирования
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: path.join(config.system.log_folder, 'error.log'), level: 'error' }),
    new winston.transports.File({ filename: path.join(config.system.log_folder, 'combined.log') }),
    new winston.transports.Console()
  ]
});

// Опции для Telegram Bot с улучшенной обработкой ошибок
const botOptions = {
  polling: {
    interval: 1000,  // Интервал опроса 1 секунда
    timeout: 10,     // Таймаут 10 секунд
    params: {
      timeout: 10,
      allowed_updates: ['message', 'callback_query', 'business_message', 'business_connection'] // Добавляем business обновления
    }
  },
  // Опции для повторных попыток подключения
  request: {
    proxy: null,  // Можно добавить прокси при необходимости
    timeout: 30000,  // 30 секунд таймаута для запросов
    agentOptions: {
      keepAlive: true,
      maxSockets: 10
    }
  }
};

// Инициализация бота с опциями
let bot;
let isBotConnected = false;
let reconnectAttempts = 0;
const maxReconnectAttempts = 10;

// Функция для инициализации бота
function initializeBot() {
  try {
    bot = new TelegramBot(config.bot.token, botOptions);
    setupBotHandlers();
    isBotConnected = true;
    reconnectAttempts = 0;
    logger.info('Бот успешно инициализирован');
    return true;
  } catch (error) {
    logger.error('Ошибка инициализации бота:', error);
    return false;
  }
}

// Функция перезапуска бота
async function restartBot() {
  if (reconnectAttempts >= maxReconnectAttempts) {
    logger.error('Превышено максимальное количество попыток переподключения');
    return false;
  }
  
  reconnectAttempts++;
  logger.info(`Попытка переподключения #${reconnectAttempts}`);
  
  try {
    if (bot) {
      await bot.stopPolling();
      logger.info('Предыдущий экземпляр бота остановлен');
    }
    
    // Задержка перед переподключением
    await new Promise(resolve => setTimeout(resolve, 5000 * reconnectAttempts));
    
    if (initializeBot()) {
      logger.info('Бот успешно перезапущен');
      return true;
    }
  } catch (error) {
    logger.error('Ошибка перезапуска бота:', error);
  }
  
  return false;
}

// Глобальные переменные
let userSessions = new Map();
let orders = [];
let users = [];
let equipment = [];
let transactions = [];

// Загрузка данных
async function loadData() {
  try {
    if (await fs.pathExists('./data/orders.json')) {
      const ordersData = await fs.readJson('./data/orders.json');
      orders = ordersData.orders;
    }
    
    if (await fs.pathExists('./data/users.json')) {
      const usersData = await fs.readJson('./data/users.json');
      users = usersData.users;
    }
    
    if (await fs.pathExists('./data/equipment.json')) {
      const equipmentData = await fs.readJson('./data/equipment.json');
      equipment = equipmentData.complects;
    }
    
    if (await fs.pathExists('./data/transactions.json')) {
      const transactionsData = await fs.readJson('./data/transactions.json');
      transactions = transactionsData.transactions;
    }
    
    logger.info('Данные успешно загружены');
  } catch (error) {
    logger.error('Ошибка загрузки данных:', error);
  }
}

// Сохранение данных
async function saveData() {
  try {
    await fs.writeJson('./data/orders.json', { orders });
    await fs.writeJson('./data/users.json', { users });
    await fs.writeJson('./data/equipment.json', { complects: equipment });
    await fs.writeJson('./data/transactions.json', { transactions });
    logger.info('Данные успешно сохранены');
  } catch (error) {
    logger.error('Ошибка сохранения данных:', error);
  }
}

// Создание резервной копии
async function createBackup() {
  try {
    const timestamp = moment().format('YYYY-MM-DD_HH-mm-ss');
    const backupDir = path.join(config.system.backup_folder, timestamp);
    
    await fs.ensureDir(backupDir);
    await fs.copy('./data', path.join(backupDir, 'data'));
    
    logger.info(`Резервная копия создана: ${backupDir}`);
  } catch (error) {
    logger.error('Ошибка создания резервной копии:', error);
  }
}

// Генерация уникального номера заказа
function generateOrderNumber() {
  return Math.floor(100 + Math.random() * 900).toString();
}

// Проверка доступности комплекта
function isComplectAvailable(complectId, date, time) {
  return !orders.some(order => 
    order.complectId === complectId && 
    order.date === date && 
    order.status !== 'cancelled'
  );
}

// Получение доступных комплектов
function getAvailableComplects(date, time) {
  return equipment.filter(complect => 
    complect.status === 'available' && 
    isComplectAvailable(complect.id, date, time)
  );
}

// Создание клавиатуры с датами
function createDateKeyboard() {
  const dates = [];
  const today = moment();
  
  for (let i = 0; i < 7; i++) {
    const date = today.clone().add(i, 'days');
    const dateStr = date.format('DD.MM.YYYY');
    dates.push([{ text: dateStr, callback_data: `date_${dateStr}` }]);
  }
  
  dates.push([{ text: '❌ Отмена', callback_data: 'cancel' }]);
  
  return {
    inline_keyboard: dates
  };
}

// Создание клавиатуры с временными интервалами
function createTimeKeyboard() {
  const times = [];
  const startHour = config.business.working_hours.start;
  const endHour = config.business.working_hours.end;
  
  for (let hour = startHour; hour < endHour; hour++) {
    for (let minute = 0; minute < 60; minute += 30) {
      const timeStr = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
      times.push([{ text: timeStr, callback_data: `time_${timeStr}` }]);
    }
  }
  
  times.push([{ text: '❌ Отмена', callback_data: 'cancel' }]);
  
  return {
    inline_keyboard: times
  };
}

// Создание клавиатуры с доступными комплектами
function createComplectsKeyboard(date, time) {
  const availableComplects = getAvailableComplects(date, time);
  const complects = availableComplects.map(complect => [{
    text: `${complect.name} - ${config.business.rental_price}₽`,
    callback_data: `complect_${complect.id}`
  }]);
  
  complects.push([{ text: '❌ Отмена', callback_data: 'cancel' }]);
  
  return {
    inline_keyboard: complects
  };
}

// Основное меню
function createMainMenu() {
  return {
    inline_keyboard: [
      [{ text: '🎧 Выбрать комплект', callback_data: 'start_order' }],
      [{ text: '📍 Адрес выдачи', callback_data: 'address' }],
      [{ text: '👨‍💼 Поддержка', callback_data: 'support' }],
      [{ text: '📋 Мои заказы', callback_data: 'my_orders' }]
    ]
  };
}

// Улучшенная обработка ошибок для Telegram API
function handleTelegramError(error, context = '') {
  if (error.code === 'EFATAL' || error.message.includes('getaddrinfo ENOTFOUND')) {
    logger.error(`Ошибка подключения к Telegram API ${context}:`, error.message);
    
    if (isBotConnected) {
      logger.warn('Потеряно подключение к Telegram, попытка восстановления...');
      isBotConnected = false;
      
      // Автоматическое восстановление через 30 секунд
      setTimeout(() => {
        if (!isBotConnected) {
          restartBot();
        }
      }, 30000);
    }
  } else if (error.code === 'ETELEGRAM') {
    logger.error(`Ошибка Telegram API ${context}:`, error.message);
  } else {
    logger.error(`Неизвестная ошибка ${context}:`, error);
  }
}

// Функция для обработки бизнес-сообщений
async function handleBusinessMessage(msg) {
  try {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const messageText = msg.text || '';
    
    logger.info(`Получено бизнес-сообщение от ${userId}: ${messageText.substring(0, 50)}...`);
    
    // Добавление пользователя бизнес-чата в базу
    if (!users.find(u => u.id === userId)) {
      users.push({
        id: userId,
        username: msg.from.username,
        first_name: msg.from.first_name,
        last_name: msg.from.last_name,
        registered_at: moment().format(),
        is_blocked: false,
        is_business_chat: true  // Отмечаем как бизнес-чат
      });
      await saveData();
    }
    
    // Автоматический ответ на бизнес-сообщения
    const businessResponse = `🎧 *Здравствуйте! Я бот аренды аудиокомплектов MGSUMICRO.*

📋 Что я могу для вас сделать:
• Помочь выбрать и арендовать аудиокомплект
• Показать доступные даты и время
• Оформить заказ и оплату
• Ответить на вопросы об аренде

🚀 Для начала работы просто напишите /start или нажмите на кнопку ниже.`;
    
    await bot.sendMessage(chatId, businessResponse, {
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [{ text: '🎧 Начать аренду', callback_data: 'start_order' }],
          [{ text: '📋 Прайс-лист', callback_data: 'price_list' }],
          [{ text: '❓ Задать вопрос', url: `https://t.me/${config.bot.support_contact.replace('@', '')}` }]
        ]
      }
    });
    
    // Дополнительно отправляем главное меню
    setTimeout(async () => {
      try {
        await bot.sendMessage(chatId, 'Выберите действие:', {
          reply_markup: createMainMenu()
        });
      } catch (error) {
        handleTelegramError(error, '[business follow-up]');
      }
    }, 2000);
    
  } catch (error) {
    handleTelegramError(error, '[business_message]');
  }
}

// Настройка обработчиков событий бота
function setupBotHandlers() {
  // Обработка ошибок polling
  bot.on('polling_error', (error) => {
    handleTelegramError(error, '[polling_error]');
  });
  
  // Обработка ошибок request
  bot.on('error', (error) => {
    handleTelegramError(error, '[request_error]');
  });
  
  // Обработка бизнес-сообщений
  bot.on('business_message', async (msg) => {
    logger.info('Получено бизнес-сообщение:', msg);
    await handleBusinessMessage(msg);
  });
  
  // Обработка подключения бизнес-аккаунта
  bot.on('business_connection', (connection) => {
    logger.info('Бизнес-подключение установлено:', connection);
  });
  
  // Команда /start
  bot.onText(/\/start/, async (msg) => {
    try {
      const chatId = msg.chat.id;
      const userId = msg.from.id;
      
      // Добавление пользователя в базу
      if (!users.find(u => u.id === userId)) {
        users.push({
          id: userId,
          username: msg.from.username,
          first_name: msg.from.first_name,
          last_name: msg.from.last_name,
          registered_at: moment().format(),
          is_blocked: false,
          is_business_chat: false  // Обычный чат
        });
        await saveData();
      }
      
      // Отправка приветственного сообщения
      const welcomeText = `🎧 *Добро пожаловать в MGSUMICRO!*

📋 *Прайс-лист:*
• Аренда: ${config.business.rental_price}₽/сутки
• Прострочка: ${config.business.overdue_price}₽/час
• Комплектов: ${config.business.max_complects} единиц

📍 *Адрес выдачи:*
${config.business.address}

👨‍💼 *Поддержка:* ${config.bot.support_contact}

Выберите действие:`;
      
      await bot.sendMessage(chatId, welcomeText, {
        parse_mode: 'Markdown',
        reply_markup: createMainMenu()
      });
      
      userSessions.delete(userId);
    } catch (error) {
      handleTelegramError(error, '[/start]');
    }
  });
  
  // Команда /admin
  bot.onText(/\/admin/, async (msg) => {
    try {
      const userId = msg.from.id;
      
      if (userId.toString() !== config.bot.admin_id) {
        return await bot.sendMessage(msg.chat.id, '❌ У вас нет прав администратора');
      }
      
      const stats = generateStatistics();
      const statsText = `📊 *Административная панель*

👥 *Пользователи:* ${stats.totalUsers}
📋 *Заказы:* ${stats.totalOrders} (оплачено: ${stats.paidOrders})
💰 *Выручка:* ${stats.totalRevenue}₽
🎧 *Комплекты:* ${stats.totalComplects} (${stats.availableComplects} доступно)

📈 *Популярность комплектов:*
${stats.complectStats}

📊 *Конверсия:* ${stats.conversionRate}%`;
      
      const adminKeyboard = {
        inline_keyboard: [
          [{ text: '📥 Экспорт данных', callback_data: 'export_data' }],
          [{ text: '🔒 Блокировка пользователя', callback_data: 'block_user' }],
          [{ text: '🎧 Управление комплектами', callback_data: 'manage_equipment' }],
          [{ text: '📋 Все заказы', callback_data: 'all_orders' }]
        ]
      };
      
      await bot.sendMessage(msg.chat.id, statsText, {
        parse_mode: 'Markdown',
        reply_markup: adminKeyboard
      });
    } catch (error) {
      handleTelegramError(error, '[/admin]');
    }
  });
  
  // Обработка callback_query
  bot.on('callback_query', async (callbackQuery) => {
    try {
      const userId = callbackQuery.from.id;
      const chatId = callbackQuery.message.chat.id;
      const data = callbackQuery.data;
      
      // Удаление предыдущих сообщений
      try {
        await bot.deleteMessage(chatId, callbackQuery.message.message_id);
      } catch (error) {
        logger.warn('Не удалось удалить сообщение:', error.message);
      }
      
      // Проверка блокировки пользователя
      const user = users.find(u => u.id === userId);
      if (user && user.is_blocked) {
        return await bot.sendMessage(chatId, '❌ Вы заблокированы администратором');
      }
      
      // Обработка действий
      switch (data) {
        case 'start_order':
          userSessions.set(userId, { step: 'select_date' });
          await bot.sendMessage(chatId, '📅 *Выберите дату аренды:*', {
            parse_mode: 'Markdown',
            reply_markup: createDateKeyboard()
          });
          break;
          
        case 'address':
          await bot.sendMessage(chatId, `📍 *Адрес выдачи:*\n${config.business.address}\n\n🕐 *Время выдачи:* 7:00–18:00 (интервалы 30 минут)`, {
            parse_mode: 'Markdown',
            reply_markup: createMainMenu()
          });
          break;
          
        case 'support':
          await bot.sendMessage(chatId, `👨‍💼 *Техническая поддержка:*\nКонтакт: ${config.bot.support_contact}\n\nПо всем вопросам обращайтесь к нашему менеджеру.`, {
            parse_mode: 'Markdown',
            reply_markup: createMainMenu()
          });
          break;
          
        case 'my_orders':
          await showUserOrders(chatId, userId);
          break;
          
        case 'cancel':
          userSessions.delete(userId);
          await bot.sendMessage(chatId, '❌ Заказ отменен', {
            reply_markup: createMainMenu()
          });
          break;
          
        case 'price_list':
          const priceText = `📋 *Прайс-лист MGSUMICRO*

🎧 *Аренда аудиокомплектов:*
• ${config.business.rental_price}₽ за сутки
• ${config.business.overdue_price}₽ за час просрочки

📍 *Адрес выдачи:* ${config.business.address}
🕐 *Время работы:* 7:00 - 18:00

💳 *Оплата:*
🏦 ${config.payment.bank_name}
💳 ${config.payment.card_number}`;
          
          await bot.sendMessage(chatId, priceText, {
            parse_mode: 'Markdown',
            reply_markup: createMainMenu()
          });
          break;
          
        default:
          // Обработка выбора даты, времени, комплекта
          if (data.startsWith('date_')) {
            const session = userSessions.get(userId) || {};
            session.date = data.replace('date_', '');
            session.step = 'select_time';
            userSessions.set(userId, session);
            
            await bot.sendMessage(chatId, '🕐 *Выберите время:*', {
              parse_mode: 'Markdown',
              reply_markup: createTimeKeyboard()
            });
          } else if (data.startsWith('time_')) {
            const session = userSessions.get(userId) || {};
            session.time = data.replace('time_', '');
            session.step = 'select_complect';
            userSessions.set(userId, session);
            
            await bot.sendMessage(chatId, '🎧 *Выберите доступный комплект:*', {
              parse_mode: 'Markdown',
              reply_markup: createComplectsKeyboard(session.date, session.time)
            });
          } else if (data.startsWith('complect_')) {
            const session = userSessions.get(userId) || {};
            session.complectId = parseInt(data.replace('complect_', ''));
            session.step = 'confirm_order';
            userSessions.set(userId, session);
            
            const complect = equipment.find(c => c.id === session.complectId);
            const orderNumber = generateOrderNumber();
            
            const confirmText = `📋 *Подтверждение заказа*

🔢 *Номер заказа:* ${orderNumber}
📅 *Дата:* ${session.date}
🕐 *Время:* ${session.time}
🎧 *Комплект:* ${complect.name}
💰 *Стоимость:* ${config.business.rental_price}₽/сутки

*Адрес выдачи:* ${config.business.address}`;
            
            session.orderNumber = orderNumber;
            session.step = 'payment';
            userSessions.set(userId, session);
            
            await bot.sendMessage(chatId, confirmText, {
              parse_mode: 'Markdown',
              reply_markup: {
                inline_keyboard: [
                  [{ text: '✅ Подтвердить', callback_data: 'confirm_payment' }],
                  [{ text: '❌ Отмена', callback_data: 'cancel' }]
                ]
              }
            });
          } else if (data === 'confirm_payment') {
            const session = userSessions.get(userId) || {};
            
            // Создание заказа
            const order = {
              id: Date.now(),
              orderNumber: session.orderNumber,
              userId: userId,
              username: callbackQuery.from.username,
              complectId: session.complectId,
              date: session.date,
              time: session.time,
              price: config.business.rental_price,
              status: 'pending_payment',
              created_at: moment().format(),
              is_business_chat: false  // Обычный заказ
            };
            
            orders.push(order);
            await saveData();
            
            // Отправка инструкций по оплате
            const paymentText = `💳 *Инструкции по оплате*

🏦 *Банк:* ${config.payment.bank_name}
💳 *Номер карты:* \`${config.payment.card_number}\`
💰 *Сумма:* ${config.business.rental_price}₽
🔢 *Назначение платежа:* Аренда комплекта ${session.orderNumber}

_После оплаты нажмите кнопку "Оплатил"_`;
            
            await bot.sendMessage(chatId, paymentText, {
              parse_mode: 'Markdown',
              reply_markup: {
                inline_keyboard: [
                  [{ text: '💳 Оплатил', callback_data: `paid_${order.id}` }],
                  [{ text: '❌ Отмена', callback_data: 'cancel' }]
                ]
              }
            });
          } else if (data.startsWith('paid_')) {
            const orderId = parseInt(data.replace('paid_', ''));
            const order = orders.find(o => o.id === orderId);
            
            if (order) {
              order.status = 'paid';
              order.paid_at = moment().format();
              
              // Создание транзакции
              const transaction = {
                id: Date.now(),
                orderId: orderId,
                userId: userId,
                amount: config.business.rental_price,
                status: 'completed',
                created_at: moment().format()
              };
              
              transactions.push(transaction);
              await saveData();
              
              // Уведомление администратора
              const adminText = `🎉 *Новый оплаченный заказ!*

🔢 *Номер:* ${order.orderNumber}
👤 *Клиент:* @${order.username} (${userId})
🎧 *Комплект:* Аудиокомплект #${order.complectId}
💰 *Сумма:* ${config.business.rental_price}₽
📅 *Дата:* ${order.date} в ${order.time}`;
              
              await bot.sendMessage(config.bot.admin_id, adminText, { parse_mode: 'Markdown' });
              
              // Сообщение клиенту
              const successText = `✅ *Оплата подтверждена!*

🔢 *Номер вашего заказа:* ${order.orderNumber}
📅 *Дата выдачи:* ${order.date}
🕐 *Время:* ${order.time}
🎧 *Комплект:* Аудиокомплект #${order.complectId}

📍 *Адрес выдачи:* ${config.business.address}

Спасибо за заказ! Не забудьте прийти вовремя.`;
              
              await bot.sendMessage(chatId, successText, {
                parse_mode: 'Markdown',
                reply_markup: createMainMenu()
              });
              
              userSessions.delete(userId);
            }
          }
      }
      
      await bot.answerCallbackQuery(callbackQuery.id);
    } catch (error) {
      handleTelegramError(error, '[callback_query]');
    }
  });
}

// Функция для показа заказов пользователя
async function showUserOrders(chatId, userId) {
  try {
    const userOrders = orders.filter(o => o.userId === userId);
    
    if (userOrders.length === 0) {
      return await bot.sendMessage(chatId, '📋 У вас пока нет заказов', {
        reply_markup: createMainMenu()
      });
    }
    
    let ordersText = '📋 *Ваши заказы:*\n\n';
    
    userOrders.forEach(order => {
      const status = order.status === 'paid' ? '✅ Оплачен' : '⏳ Ожидание оплаты';
      ordersText += `🔢 *№${order.orderNumber}*
🎧 *Комплект:* #${order.complectId}
📅 *Дата:* ${order.date} в ${order.time}
💰 *Сумма:* ${order.price}₽
📊 *Статус:* ${status}\n\n`;
    });
    
    await bot.sendMessage(chatId, ordersText, {
      parse_mode: 'Markdown',
      reply_markup: createMainMenu()
    });
  } catch (error) {
    handleTelegramError(error, '[showUserOrders]');
  }
}

// Функция генерации статистики
function generateStatistics() {
  const totalUsers = users.length;
  const totalOrders = orders.length;
  const paidOrders = orders.filter(o => o.status === 'paid').length;
  const totalRevenue = paidOrders * config.business.rental_price;
  const totalComplects = equipment.length;
  const availableComplects = equipment.filter(c => c.status === 'available').length;
  
  // Статистика по комплектам
  const complectStats = equipment.map(complect => {
    const usageCount = orders.filter(o => o.complectId === complect.id && o.status === 'paid').length;
    return `• ${complect.name}: ${usageCount} аренд`;
  }).join('\n');
  
  // Конверсия
  const conversionRate = totalUsers > 0 ? ((paidOrders / totalUsers) * 100).toFixed(1) : 0;
  
  return {
    totalUsers,
    totalOrders,
    paidOrders,
    totalRevenue,
    totalComplects,
    availableComplects,
    complectStats,
    conversionRate
  };
}

// Автоматическое напоминание о завершении аренды
cron.schedule('0 */2 * * *', async () => {
  if (!isBotConnected) return;
  
  const now = moment();
  
  for (const order of orders) {
    if (order.status === 'paid') {
      const orderDateTime = moment(`${order.date} ${order.time}`, 'DD.MM.YYYY HH:mm');
      const endTime = orderDateTime.clone().add(24, 'hours');
      
      // Напоминание за 2 часа до окончания
      if (now.isSame(endTime.clone().subtract(2, 'hours'), 'minute')) {
        const reminderText = `⏰ *Напоминание о завершении аренды*

🔢 *Заказ:* ${order.orderNumber}
🎧 *Комплект:* #${order.complectId}
📅 *Завершение:* ${endTime.format('DD.MM.YYYY HH:mm')}

Пожалуйста, верните комплект вовремя. При просрочке - ${config.business.overdue_price}₽/час.`;
        
        try {
          await bot.sendMessage(order.userId, reminderText, { parse_mode: 'Markdown' });
        } catch (error) {
          handleTelegramError(error, '[reminder]');
        }
      }
    }
  }
});

// Резервное копирование каждый день
cron.schedule(config.system.backup_interval, () => {
  createBackup();
});

// Периодическая проверка подключения
cron.schedule('*/5 * * * *', () => {
  if (!isBotConnected && reconnectAttempts < maxReconnectAttempts) {
    logger.info('Попытка автоматического восстановления подключения...');
    restartBot();
  }
});

// Инициализация
async function init() {
  try {
    await fs.ensureDir(config.system.data_folder);
    await fs.ensureDir(config.system.backup_folder);
    await fs.ensureDir(config.system.log_folder);
    
    await loadData();
    
    if (initializeBot()) {
      // Уведомление администратора о запуске
      try {
        await bot.sendMessage(config.bot.admin_id, '🤖 *Бот MGSUMICRO запущен!*\n\nСистема аренды аудиокомплектов готова к работе.\n\n✅ Поддержка бизнес-чатов активирована\n✅ Автоматическое восстановление подключения\n✅ Обработка 25 комплектов', {
          parse_mode: 'Markdown'
        });
      } catch (error) {
        logger.warn('Не удалось отправить уведомление администратору:', error.message);
      }
      
      logger.info('Бот успешно запущен');
    } else {
      logger.error('Не удалось запустить бота');
      process.exit(1);
    }
  } catch (error) {
    logger.error('Ошибка инициализации:', error);
    process.exit(1);
  }
}

// Обработка глобальных ошибок
process.on('uncaughtException', (error) => {
  logger.error('Необработанная ошибка:', error);
  if (error.message.includes('ENOTFOUND') || error.message.includes('ECONNRESET')) {
    logger.info('Попытка восстановления после глобальной ошибки...');
    setTimeout(() => restartBot(), 5000);
  }
});

process.on('unhandledRejection', (reason, promise) => {
  logger.error('Необработанный rejection:', reason);
  if (reason.message && (reason.message.includes('ENOTFOUND') || reason.message.includes('ECONNRESET'))) {
    logger.info('Попытка восстановления после rejection...');
    setTimeout(() => restartBot(), 5000);
  }
});

// Graceful shutdown
process.on('SIGINT', async () => {
  logger.info('Получен сигнал SIGINT, завершение работы...');
  if (bot) {
    await bot.stopPolling();
  }
  process.exit(0);
});

process.on('SIGTERM', async () => {
  logger.info('Получен сигнал SIGTERM, завершение работы...');
  if (bot) {
    await bot.stopPolling();
  }
  process.exit(0);
});

// Запуск приложения
init();