const fs = require('fs-extra');
const path = require('path');

// Утилиты для администратора
class AdminTools {
    constructor() {
        this.dataDir = './data';
        this.equipmentFile = path.join(this.dataDir, 'equipment.json');
        this.usersFile = path.join(this.dataDir, 'users.json');
        this.ordersFile = path.join(this.dataDir, 'orders.json');
    }

    // Добавление нового комплекта
    async addComplect(name, description = 'Учебный аудиокомплект для занятий') {
        try {
            const equipmentData = await fs.readJson(this.equipmentFile);
            const newId = Math.max(...equipmentData.complects.map(c => c.id), 0) + 1;
            
            const newComplect = {
                id: newId,
                name: name || `Аудиокомплект #${newId}`,
                status: 'available',
                description: description
            };
            
            equipmentData.complects.push(newComplect);
            await fs.writeJson(this.equipmentFile, equipmentData);
            
            console.log(`✅ Комплект добавлен: ${newComplect.name} (ID: ${newId})`);
            return newComplect;
        } catch (error) {
            console.error('❌ Ошибка добавления комплекта:', error);
        }
    }

    // Удаление комплекта
    async removeComplect(complectId) {
        try {
            const equipmentData = await fs.readJson(this.equipmentFile);
            const initialLength = equipmentData.complects.length;
            
            equipmentData.complects = equipmentData.complects.filter(c => c.id !== complectId);
            
            if (equipmentData.complects.length < initialLength) {
                await fs.writeJson(this.equipmentFile, equipmentData);
                console.log(`✅ Комплект ID:${complectId} удален`);
                return true;
            } else {
                console.log(`❌ Комплект ID:${complectId} не найден`);
                return false;
            }
        } catch (error) {
            console.error('❌ Ошибка удаления комплекта:', error);
        }
    }

    // Изменение статуса комплекта
    async updateComplectStatus(complectId, status) {
        try {
            const equipmentData = await fs.readJson(this.equipmentFile);
            const complect = equipmentData.complects.find(c => c.id === complectId);
            
            if (complect) {
                complect.status = status;
                await fs.writeJson(this.equipmentFile, equipmentData);
                console.log(`✅ Статус комплекта ID:${complectId} изменен на: ${status}`);
                return true;
            } else {
                console.log(`❌ Комплект ID:${complectId} не найден`);
                return false;
            }
        } catch (error) {
            console.error('❌ Ошибка обновления статуса:', error);
        }
    }

    // Блокировка пользователя
    async blockUser(userId) {
        try {
            const usersData = await fs.readJson(this.usersFile);
            const user = usersData.users.find(u => u.id === parseInt(userId));
            
            if (user) {
                user.is_blocked = true;
                await fs.writeJson(this.usersFile, usersData);
                console.log(`✅ Пользователь ID:${userId} заблокирован`);
                return true;
            } else {
                console.log(`❌ Пользователь ID:${userId} не найден`);
                return false;
            }
        } catch (error) {
            console.error('❌ Ошибка блокировки пользователя:', error);
        }
    }

    // Разблокировка пользователя
    async unblockUser(userId) {
        try {
            const usersData = await fs.readJson(this.usersFile);
            const user = usersData.users.find(u => u.id === parseInt(userId));
            
            if (user) {
                user.is_blocked = false;
                await fs.writeJson(this.usersFile, usersData);
                console.log(`✅ Пользователь ID:${userId} разблокирован`);
                return true;
            } else {
                console.log(`❌ Пользователь ID:${userId} не найден`);
                return false;
            }
        } catch (error) {
            console.error('❌ Ошибка разблокировки пользователя:', error);
        }
    }

    // Экспорт статистики
    async exportStatistics() {
        try {
            const ordersData = await fs.readJson(this.ordersFile);
            const usersData = await fs.readJson(this.usersFile);
            const equipmentData = await fs.readJson(this.equipmentFile);
            
            const stats = {
                totalUsers: usersData.users.length,
                totalOrders: ordersData.orders.length,
                paidOrders: ordersData.orders.filter(o => o.status === 'paid').length,
                pendingOrders: ordersData.orders.filter(o => o.status === 'pending_payment').length,
                totalComplects: equipmentData.complects.length,
                availableComplects: equipmentData.complects.filter(c => c.status === 'available').length,
                totalRevenue: ordersData.orders.filter(o => o.status === 'paid').length * 600,
                generatedAt: new Date().toISOString()
            };
            
            const statsFile = path.join('./backups', `stats_${new Date().toISOString().split('T')[0]}.json`);
            await fs.writeJson(statsFile, stats);
            
            console.log('📊 Статистика экспортирована:', statsFile);
            console.log('📈 Общая статистика:');
            console.log(`   👥 Пользователей: ${stats.totalUsers}`);
            console.log(`   📋 Всего заказов: ${stats.totalOrders}`);
            console.log(`   💰 Оплачено: ${stats.paidOrders}`);
            console.log(`   💵 Выручка: ${stats.totalRevenue}₽`);
            
            return stats;
        } catch (error) {
            console.error('❌ Ошибка экспорта статистики:', error);
        }
    }

    // Просмотр всех заказов
    async listAllOrders() {
        try {
            const ordersData = await fs.readJson(this.ordersFile);
            
            console.log('📋 Все заказы:');
            console.log('=' .repeat(50));
            
            ordersData.orders.forEach(order => {
                console.log(`🔢 №${order.orderNumber} | ${order.date} ${order.time}`);
                console.log(`👤 Клиент: @${order.username} (${order.userId})`);
                console.log(`🎧 Комплект: #${order.complectId}`);
                console.log(`💰 Сумма: ${order.price}₽`);
                console.log(`📊 Статус: ${order.status}`);
                console.log(`📅 Создан: ${order.created_at}`);
                console.log('-' .repeat(30));
            });
            
            return ordersData.orders;
        } catch (error) {
            console.error('❌ Ошибка чтения заказов:', error);
        }
    }

    // Инициализация оборудования (25 комплектов)
    async initializeEquipment() {
        try {
            const equipmentData = { complects: [] };
            
            for (let i = 1; i <= 25; i++) {
                equipmentData.complects.push({
                    id: i,
                    name: `Аудиокомплект #${i}`,
                    status: 'available',
                    description: 'Учебный аудиокомплект для занятий'
                });
            }
            
            await fs.writeJson(this.equipmentFile, equipmentData);
            console.log('✅ Оборудование инициализировано: 25 комплектов');
        } catch (error) {
            console.error('❌ Ошибка инициализации оборудования:', error);
        }
    }
}

// CLI интерфейс
if (require.main === module) {
    const adminTools = new AdminTools();
    const command = process.argv[2];
    
    switch (command) {
        case 'init-equipment':
            adminTools.initializeEquipment();
            break;
            
        case 'add-complect':
            const name = process.argv[3];
            const description = process.argv[4] || 'Учебный аудиокомплект для занятий';
            adminTools.addComplect(name, description);
            break;
            
        case 'remove-complect':
            const complectId = parseInt(process.argv[3]);
            adminTools.removeComplect(complectId);
            break;
            
        case 'block-user':
            const userId = process.argv[3];
            adminTools.blockUser(userId);
            break;
            
        case 'unblock-user':
            adminTools.unblockUser(process.argv[3]);
            break;
            
        case 'export-stats':
            adminTools.exportStatistics();
            break;
            
        case 'list-orders':
            adminTools.listAllOrders();
            break;
            
        default:
            console.log('🛠️  Утилиты администратора MGSUMICRO');
            console.log('');
            console.log('Команды:');
            console.log('  init-equipment     - Инициализировать 25 комплектов');
            console.log('  add-complect [name] [desc] - Добавить комплект');
            console.log('  remove-complect [id] - Удалить комплект');
            console.log('  block-user [user_id] - Заблокировать пользователя');
            console.log('  unblock-user [user_id] - Разблокировать пользователя');
            console.log('  export-stats       - Экспорт статистики');
            console.log('  list-orders        - Показать все заказы');
            console.log('');
            console.log('Примеры:');
            console.log('  node admin-tools.js add-complect "Профессиональный комплект" "VIP оборудование"');
            console.log('  node admin-tools.js block-user 123456789');
            break;
    }
}

module.exports = AdminTools;